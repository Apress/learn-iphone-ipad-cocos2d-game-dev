//
//  OtherScene.h
//  ScenesAndLayers
//


#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface OtherScene : CCLayer 
{
	
}

+(void) simulateLongLoadingTime;

+(id) scene;

@end
