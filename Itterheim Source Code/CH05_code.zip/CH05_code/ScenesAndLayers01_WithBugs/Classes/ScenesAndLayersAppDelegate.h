//
//  ScenesAndLayersAppDelegate.h
//  ScenesAndLayers
//
//  Created by Steffen Itterheim on 27.07.10.
//  Copyright Steffen Itterheim 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScenesAndLayersAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
