//
//  FirstScene.h
//  ScenesAndLayers
//


#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface FirstScene : CCLayer 
{
	
}

+(id) scene;

@end
