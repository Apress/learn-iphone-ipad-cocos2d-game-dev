//
//  OtherScene.h
//  ScenesAndLayers
//


#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface OtherScene : CCLayer 
{
	
}

+(id) scene;

@end
