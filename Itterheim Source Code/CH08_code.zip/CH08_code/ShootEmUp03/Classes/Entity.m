//
//  Entity.m
//  ShootEmUp
//
//  Created by Steffen Itterheim on 18.08.10.
//  Copyright 2010 Steffen Itterheim. All rights reserved.
//

#import "Entity.h"
#import "GameScene.h"

@implementation Entity


@end
