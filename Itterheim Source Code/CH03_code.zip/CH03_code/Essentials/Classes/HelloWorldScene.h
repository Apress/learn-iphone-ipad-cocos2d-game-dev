//
//  HelloWorldLayer.h
//  Essentials
//
//  Created by Steffen Itterheim on 14.07.10.
//  Copyright Steffen Itterheim 2010. All rights reserved.
//

#import "cocos2d.h"

@interface HelloWorld : CCLayer
{
}

// returns a Scene that contains the HelloWorld as the only child
+(id) scene;

@end
