//
//  GameScene.h
//  DoodleDrop
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface GameScene : CCLayer 
{

}

+(id) scene;

@end
