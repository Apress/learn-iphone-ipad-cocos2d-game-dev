//
//  DoodleDropAppDelegate.h
//  DoodleDrop
//
//  Created by Steffen Itterheim on 19.07.10.
//  Copyright Steffen Itterheim 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoodleDropAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
