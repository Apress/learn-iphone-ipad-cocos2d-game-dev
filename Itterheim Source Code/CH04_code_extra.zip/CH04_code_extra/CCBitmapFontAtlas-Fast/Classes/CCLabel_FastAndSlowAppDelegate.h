//
//  CCLabel_FastAndSlowAppDelegate.h
//  CCLabel-FastAndSlow
//
//  Created by Steffen Itterheim on 22.07.10.
//  Copyright Steffen Itterheim 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCLabel_FastAndSlowAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
