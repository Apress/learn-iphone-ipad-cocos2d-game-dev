//
//  SpriteBatchesAppDelegate.h
//  SpriteBatches
//
//  Created by Steffen Itterheim on 04.08.10.
//  Copyright Steffen Itterheim 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpriteBatchesAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
